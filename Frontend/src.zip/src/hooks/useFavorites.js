import { useEffect, useState } from "react";

const STORAGE_KEY = "askmycity_favorites";
const FAVORITES_CHANGED_EVENT =
  "askmycity-favorites-changed";

function readFavorites() {
  try {
    const storedFavorites =
      localStorage.getItem(STORAGE_KEY);

    if (!storedFavorites) {
      return [];
    }

    const parsedFavorites =
      JSON.parse(storedFavorites);

    return Array.isArray(parsedFavorites)
      ? parsedFavorites
      : [];
  } catch (error) {
    console.error(
      "Could not read favorites:",
      error
    );

    return [];
  }
}

function saveFavorites(favorites) {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(favorites)
    );

    window.dispatchEvent(
      new CustomEvent(
        FAVORITES_CHANGED_EVENT,
        {
          detail: favorites,
        }
      )
    );
  } catch (error) {
    console.error(
      "Could not save favorites:",
      error
    );
  }
}

export default function useFavorites() {
  const [favorites, setFavorites] = useState(
    readFavorites
  );

  useEffect(() => {
    function handleFavoritesChanged(event) {
      if (Array.isArray(event.detail)) {
        setFavorites(event.detail);
      } else {
        setFavorites(readFavorites());
      }
    }

    function handleStorageChange(event) {
      if (event.key === STORAGE_KEY) {
        setFavorites(readFavorites());
      }
    }

    window.addEventListener(
      FAVORITES_CHANGED_EVENT,
      handleFavoritesChanged
    );

    window.addEventListener(
      "storage",
      handleStorageChange
    );

    return () => {
      window.removeEventListener(
        FAVORITES_CHANGED_EVENT,
        handleFavoritesChanged
      );

      window.removeEventListener(
        "storage",
        handleStorageChange
      );
    };
  }, []);

  function isFavorite(placeId) {
    return favorites.some(
      (favorite) =>
        String(favorite.id) ===
        String(placeId)
    );
  }

  function addFavorite(place) {
    const alreadySaved = favorites.some(
      (favorite) =>
        String(favorite.id) ===
        String(place.id)
    );

    if (alreadySaved) {
      return;
    }

    const updatedFavorites = [
      ...favorites,
      place,
    ];

    setFavorites(updatedFavorites);
    saveFavorites(updatedFavorites);
  }

  function removeFavorite(placeId) {
    const updatedFavorites =
      favorites.filter(
        (favorite) =>
          String(favorite.id) !==
          String(placeId)
      );

    setFavorites(updatedFavorites);
    saveFavorites(updatedFavorites);
  }

  function toggleFavorite(place) {
    if (isFavorite(place.id)) {
      removeFavorite(place.id);
    } else {
      addFavorite(place);
    }
  }

  function clearFavorites() {
    setFavorites([]);
    saveFavorites([]);
  }

  return {
    favorites,
    favoriteCount: favorites.length,
    isFavorite,
    addFavorite,
    removeFavorite,
    toggleFavorite,
    clearFavorites,
  };
}