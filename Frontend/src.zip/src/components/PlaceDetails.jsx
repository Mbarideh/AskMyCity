import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { getPlace } from "../services/api";
import useFavorites from "../hooks/useFavorites";
import {
  getPlaceFallbackImage,
  getPlaceImages,
} from "../utils/placeImages";
import "./PlaceDetails.css";

function normalizeWebsite(url) {
  if (!url) return "";
  return /^https?:\/\//i.test(url) ? url : `https://${url}`;
}

function parseHours(place) {
  const raw = place?.working_hours_json || place?.working_hours;
  if (!raw) return [];

  if (Array.isArray(raw)) return raw.map(String);

  if (typeof raw === "object") {
    return Object.entries(raw).map(([day, hours]) => `${day}: ${hours}`);
  }

  if (typeof raw !== "string") return [];

  try {
    return parseHours({ working_hours: JSON.parse(raw) });
  } catch {
    return raw
      .split(/\n|\|/)
      .map((line) => line.trim())
      .filter(Boolean);
  }
}

export default function PlaceDetails() {
  const { placeId } = useParams();
  const navigate = useNavigate();
  const { isFavorite, toggleFavorite } = useFavorites();

  const [place, setPlace] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });

    async function loadPlace() {
      try {
        setLoading(true);
        setError("");
        const data = await getPlace(placeId);
        setPlace(data);
      } catch (requestError) {
        console.error("Could not load business:", requestError);
        setError(requestError.message || "Could not load this business.");
      } finally {
        setLoading(false);
      }
    }

    loadPlace();
  }, [placeId]);

  const images = useMemo(() => getPlaceImages(place || {}), [place]);
  const hours = useMemo(() => parseHours(place), [place]);

  if (loading) {
    return (
      <main className="details-page">
        <div className="details-container">
          <div className="status-card">
            <div className="spinner" />
            <p>Loading business...</p>
          </div>
        </div>
      </main>
    );
  }

  if (error || !place) {
    return (
      <main className="details-page">
        <div className="details-container">
          <div className="status-card error-card">
            <h2>Business not found</h2>
            <p>{error || "This business could not be found."}</p>
            <button type="button" className="back-button" onClick={() => navigate("/")}>
              Back to AskMyCity
            </button>
          </div>
        </div>
      </main>
    );
  }

  const rating = place.rating ?? "Not rated";
  const reviewCount = place.review_count ?? 0;
  const address =
    place.full_address ||
    place.address ||
    [place.city, place.state, place.postal_code].filter(Boolean).join(", ");
  const website = normalizeWebsite(place.website);
  const saved = isFavorite(place.id);

  function handleImageError(event) {
    event.currentTarget.onerror = null;
    event.currentTarget.src = getPlaceFallbackImage(place);
  }

  return (
    <main className="details-page">
      <div className="details-container">
        <header className="details-toolbar">
          <button type="button" className="back-button" onClick={() => navigate(-1)}>
            ← Back to results
          </button>
          <button
            type="button"
            className={`details-save ${saved ? "saved" : ""}`}
            onClick={() => toggleFavorite(place)}
            aria-pressed={saved}
          >
            {saved ? "♥ Saved" : "♡ Save business"}
          </button>
        </header>

        <section className="details-gallery" aria-label={`${place.name} photos`}>
          <div className="details-gallery-main">
            <img
              src={images[activeImage] || getPlaceFallbackImage(place)}
              alt={`${place.name} business`}
              onError={handleImageError}
            />
            <div className="details-image-overlay" />
            <div className="details-hero-content">
              <div className="details-badges">
                <span className="details-category">{place.category || "Local business"}</span>
                {place.verified && <span className="details-verified">✓ Verified</span>}
              </div>
              <h1>{place.name}</h1>
              <div className="details-rating">
                <span>★</span>
                <strong>{rating}</strong>
                <span>({reviewCount} review{reviewCount === 1 ? "" : "s"})</span>
              </div>
            </div>
          </div>

          {images.length > 1 && (
            <div className="details-thumbnails">
              {images.slice(0, 5).map((image, index) => (
                <button
                  type="button"
                  key={`${image}-${index}`}
                  className={activeImage === index ? "active" : ""}
                  onClick={() => setActiveImage(index)}
                  aria-label={`View photo ${index + 1}`}
                >
                  <img src={image} alt="" onError={handleImageError} />
                </button>
              ))}
            </div>
          )}
        </section>

        <section className="details-layout">
          <div className="details-main">
            <article className="details-section">
              <p className="section-kicker">OVERVIEW</p>
              <h2>About this business</h2>
              <p>
                {place.description ||
                  `${place.name} is a local ${place.category || "business"} serving ${
                    place.city || "the surrounding community"
                  }.`}
              </p>
            </article>

            <article className="details-section">
              <p className="section-kicker">INFORMATION</p>
              <h2>Business details</h2>
              <div className="information-list">
                {address && (
                  <div className="information-row">
                    <span className="information-icon">📍</span>
                    <div><strong>Address</strong><p>{address}</p></div>
                  </div>
                )}
                {place.phone_number && (
                  <div className="information-row">
                    <span className="information-icon">📞</span>
                    <div><strong>Phone</strong><p><a href={`tel:${place.phone_number}`}>{place.phone_number}</a></p></div>
                  </div>
                )}
                {website && (
                  <div className="information-row">
                    <span className="information-icon">🌐</span>
                    <div><strong>Website</strong><p><a href={website} target="_blank" rel="noreferrer">Visit website</a></p></div>
                  </div>
                )}
                <div className="information-row">
                  <span className="information-icon">🏷️</span>
                  <div><strong>Category</strong><p>{place.category || "Local business"}</p></div>
                </div>
              </div>
            </article>

            {hours.length > 0 && (
              <article className="details-section">
                <p className="section-kicker">OPENING HOURS</p>
                <h2>Business hours</h2>
                <div className="hours-list">
                  {hours.map((line, index) => <p key={`${line}-${index}`}>{line}</p>)}
                </div>
              </article>
            )}

            <article className="details-section">
              <p className="section-kicker">REVIEWS</p>
              <h2>Customer rating</h2>
              <div className="rating-summary">
                <div className="rating-number">{rating}</div>
                <div><div className="large-stars">★★★★★</div><p>Based on {reviewCount} review{reviewCount === 1 ? "" : "s"}</p></div>
              </div>
            </article>
          </div>

          <aside className="contact-panel">
            <h2>Contact this business</h2>
            <p>Call, visit the website, or open directions in Google Maps.</p>
            {place.phone_number && <a className="contact-button contact-primary" href={`tel:${place.phone_number}`}>📞 Call now</a>}
            {website && <a className="contact-button contact-secondary" href={website} target="_blank" rel="noreferrer">🌐 Visit website</a>}
            {place.google_maps_url && <a className="contact-button contact-secondary" href={place.google_maps_url} target="_blank" rel="noreferrer">📍 Get directions</a>}
            <button type="button" className={`contact-button save-button ${saved ? "saved" : ""}`} onClick={() => toggleFavorite(place)}>
              {saved ? "♥ Saved" : "♡ Save business"}
            </button>
          </aside>
        </section>
      </div>
    </main>
  );
}
