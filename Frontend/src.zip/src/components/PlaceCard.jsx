import useFavorites from "../hooks/useFavorites";

import { getPlaceFallbackImage, getPrimaryPlaceImage } from "../utils/placeImages";
import "./PlaceCard.css";

const temporaryImages = [
  "https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=900&q=80",
  "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=900&q=80",
  "https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=900&q=80",
  "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?auto=format&fit=crop&w=900&q=80",
];

function getTemporaryImage(place) {
  const placeId = Number(place.id) || 0;

  return temporaryImages[
    placeId % temporaryImages.length
  ];
}

export default function PlaceCard({
  place,
  onSelect,
}) {
  const {
    isFavorite,
    toggleFavorite,
  } = useFavorites();

  const saved = isFavorite(place.id);

  const imageUrl = getPrimaryPlaceImage(place);

  const rating =
    place.rating !== null &&
    place.rating !== undefined
      ? place.rating
      : "Not rated";

  const reviewCount =
    place.review_count !== null &&
    place.review_count !== undefined
      ? place.review_count
      : 0;

  const distance =
    place.distance_km !== null &&
    place.distance_km !== undefined;

  function stopCardClick(event) {
    event.stopPropagation();
  }

  function handleFavoriteClick(event) {
    event.stopPropagation();
    toggleFavorite(place);
  }

  function handleCardKeyDown(event) {
    if (
      event.target.closest(
        "button, a"
      )
    ) {
      return;
    }

    if (
      event.key === "Enter" ||
      event.key === " "
    ) {
      event.preventDefault();
      onSelect(place);
    }
  }

  return (
    <article
      className="place-card"
      onClick={() => onSelect(place)}
      role="button"
      tabIndex={0}
      onKeyDown={handleCardKeyDown}
    >
      <div className="place-image-wrapper">
        <img
          className="place-image"
          src={imageUrl}
          alt={`${place.name} business`}
          loading="lazy"
          onError={(event) => {
            event.currentTarget.onerror = null;
            event.currentTarget.src = getPlaceFallbackImage(place);
          }}
        />

        <div className="image-overlay" />

        {place.verified && (
          <span className="verified-badge">
            ✓ Verified
          </span>
        )}

        {distance && (
          <span className="distance-badge">
            📍 {place.distance_km} km away
          </span>
        )}

        <button
          type="button"
          className={
            saved
              ? "favorite-button saved"
              : "favorite-button"
          }
          aria-label={
            saved
              ? `Remove ${place.name} from favorites`
              : `Save ${place.name} to favorites`
          }
          aria-pressed={saved}
          title={
            saved
              ? "Remove from favorites"
              : "Save business"
          }
          onClick={handleFavoriteClick}
        >
          <span aria-hidden="true">
            {saved ? "♥" : "♡"}
          </span>
        </button>
      </div>

      <div className="place-content">
        <p className="place-category">
          {place.category ||
            "Local business"}
        </p>

        <h3>{place.name}</h3>

        <div className="rating-row">
          <span className="rating-star">
            ★
          </span>

          <strong>{rating}</strong>

          <span className="review-count">
            ({reviewCount} review
            {reviewCount === 1 ? "" : "s"})
          </span>
        </div>

        <div className="place-information">
          <p>
            <span>📍</span>

            <span>
              {place.city ||
                "Location unavailable"}

              {place.state
                ? `, ${place.state}`
                : ""}
            </span>
          </p>

          {place.phone_number && (
            <p>
              <span>📞</span>

              <a
                href={`tel:${place.phone_number}`}
                onClick={stopCardClick}
              >
                {place.phone_number}
              </a>
            </p>
          )}
        </div>

        <div className="place-actions">
          {place.phone_number && (
            <a
              className="place-action primary-action"
              href={`tel:${place.phone_number}`}
              onClick={stopCardClick}
            >
              Call
            </a>
          )}

          {place.website && (
            <a
              className="place-action secondary-action"
              href={place.website}
              target="_blank"
              rel="noreferrer"
              onClick={stopCardClick}
            >
              Website
            </a>
          )}

          {place.google_maps_url && (
            <a
              className="place-action secondary-action"
              href={place.google_maps_url}
              target="_blank"
              rel="noreferrer"
              onClick={stopCardClick}
            >
              Directions
            </a>
          )}
        </div>
      </div>
    </article>
  );
}