import { useEffect, useMemo, useRef, useState } from "react";

import BusinessMap from "./BusinessMap";

import "./AISearchBox.css";

const STARTER_PROMPTS = [
  {
    icon: "🔧",
    title: "Home repair",
    prompt: "Find a highly rated plumber in Ottawa",
  },
  {
    icon: "⚡",
    title: "Urgent help",
    prompt: "I need an emergency electrician near me",
  },
  {
    icon: "🍽️",
    title: "Food nearby",
    prompt: "Show me family-friendly restaurants in Kanata",
  },
  {
    icon: "🦷",
    title: "Language preference",
    prompt: "Find a dentist who speaks Persian",
  },
];

function ResultCard({ place, rank, onSelect }) {
  const rating = place.rating ?? "Not rated";
  const reviewCount = place.review_count ?? 0;
  const hasDistance =
    place.distance_km !== null && place.distance_km !== undefined;

  function stopPropagation(event) {
    event.stopPropagation();
  }

  return (
    <article
      className="chat-result-card"
      onClick={() => onSelect(place)}
      onKeyDown={(event) => {
        if (event.target.closest("a, button")) return;
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onSelect(place);
        }
      }}
      role="button"
      tabIndex={0}
    >
      <div className="chat-result-rank">{rank}</div>

      <div className="chat-result-body">
        <div className="chat-result-heading">
          <div>
            <p>{place.category || "Local business"}</p>
            <h3>{place.name}</h3>
          </div>

          {place.verified && <span className="chat-verified">✓ Verified</span>}
        </div>

        <div className="chat-result-meta">
          <span className="chat-rating">★ {rating}</span>
          <span>
            {reviewCount} review{reviewCount === 1 ? "" : "s"}
          </span>
          {hasDistance && <span>📍 {place.distance_km} km away</span>}
          {place.city && (
            <span>
              {place.city}
              {place.state ? `, ${place.state}` : ""}
            </span>
          )}
        </div>

        <div className="chat-result-actions">
          <button type="button" onClick={() => onSelect(place)}>
            View details
          </button>

          {place.phone_number && (
            <a href={`tel:${place.phone_number}`} onClick={stopPropagation}>
              Call
            </a>
          )}

          {place.google_maps_url && (
            <a
              href={place.google_maps_url}
              target="_blank"
              rel="noreferrer"
              onClick={stopPropagation}
            >
              Directions
            </a>
          )}
        </div>
      </div>
    </article>
  );
}

export default function AISearchBox({
  onSearch,
  onNewChat,
  onPlaceSelect,
  messages = [],
  results = [],
  explanation = "",
  urgency = "",
  loading = false,
  locationMessage = "",
}) {
  const [query, setQuery] = useState("");
  const [resultView, setResultView] = useState("list");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  const hasConversation = messages.length > 0;

  const recentSearches = useMemo(
    () =>
      messages
        .filter((message) => message.role === "user")
        .map((message) => message.content)
        .reverse()
        .slice(0, 6),
    [messages]
  );

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "end",
    });
  }, [messages, loading, locationMessage, results, resultView]);

  useEffect(() => {
    setResultView("list");
  }, [results]);

  function resizeTextarea() {
    const textarea = textareaRef.current;
    if (!textarea) return;

    textarea.style.height = "auto";
    textarea.style.height = `${Math.min(textarea.scrollHeight, 160)}px`;
  }

  function submitQuery(value) {
    const cleanedQuery = String(value || "").trim();

    if (cleanedQuery.length < 3 || loading) return;

    onSearch(cleanedQuery);
    setQuery("");
    setSidebarOpen(false);

    requestAnimationFrame(() => {
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
        textareaRef.current.focus();
      }
    });
  }

  function handleSubmit(event) {
    event.preventDefault();
    submitQuery(query);
  }

  function handleKeyDown(event) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submitQuery(query);
    }
  }

  function handleNewChat() {
    if (loading) return;

    setQuery("");
    setResultView("list");
    setSidebarOpen(false);
    onNewChat();
    textareaRef.current?.focus();
  }

  return (
    <section className="ai-workspace" aria-label="AskMyCity AI assistant">
      <button
        type="button"
        className={`sidebar-backdrop ${sidebarOpen ? "visible" : ""}`}
        aria-label="Close sidebar"
        onClick={() => setSidebarOpen(false)}
      />

      <aside className={`ai-sidebar ${sidebarOpen ? "open" : ""}`}>
        <div className="sidebar-brand">
          <span className="sidebar-logo" aria-hidden="true">
            <span>⌖</span>
            <i>✦</i>
          </span>
          <strong>AskMyCity</strong>
        </div>

        <button type="button" className="sidebar-new-chat" onClick={handleNewChat}>
          <span>＋</span>
          New chat
        </button>

        <nav className="sidebar-navigation" aria-label="Main navigation">
          <button type="button" className="active">
            <span>💬</span> Ask AI
          </button>
          <button type="button">
            <span>🧭</span> Explore
          </button>
          <button type="button">
            <span>♡</span> Favorites
          </button>
        </nav>

        <div className="sidebar-history">
          <p>RECENT</p>

          {recentSearches.length > 0 ? (
            recentSearches.map((search, index) => (
              <button
                type="button"
                key={`${search}-${index}`}
                onClick={() => submitQuery(search)}
                title={search}
              >
                <span>◷</span>
                <span>{search}</span>
              </button>
            ))
          ) : (
            <span className="sidebar-empty">Your searches will appear here.</span>
          )}
        </div>

        <div className="sidebar-footer">
          <div className="sidebar-avatar">M</div>
          <div>
            <strong>Mohammad</strong>
            <span>Local explorer</span>
          </div>
          <button type="button" aria-label="Settings">⚙</button>
        </div>
      </aside>

      <div className="ai-main-panel">
        <header className="ai-topbar">
          <button
            type="button"
            className="mobile-menu-button"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open sidebar"
          >
            ☰
          </button>

          <div>
            <strong>AskMyCity AI</strong>
            <span>
              <i /> Local search assistant
            </span>
          </div>

          <button
            type="button"
            className="topbar-new-chat"
            onClick={handleNewChat}
            disabled={loading || !hasConversation}
          >
            ＋ New chat
          </button>
        </header>

        <div className={`ai-conversation ${!hasConversation ? "empty" : ""}`}>
          {!hasConversation ? (
            <div className="ai-welcome-state">
              <span className="ai-welcome-logo" aria-hidden="true">
                <span>⌖</span>
                <i>✦</i>
              </span>

              <p className="ai-welcome-kicker">YOUR LOCAL AI CONCIERGE</p>
              <h1>What are you looking for today?</h1>
              <p className="ai-welcome-copy">
                Describe what you need in your own words. I’ll find and compare
                the best local options for you.
              </p>

              <div className="ai-starter-grid">
                {STARTER_PROMPTS.map((item) => (
                  <button
                    key={item.prompt}
                    type="button"
                    className="ai-starter-card"
                    onClick={() => submitQuery(item.prompt)}
                    disabled={loading}
                  >
                    <span className="starter-icon">{item.icon}</span>
                    <span>
                      <strong>{item.title}</strong>
                      <small>{item.prompt}</small>
                    </span>
                    <b aria-hidden="true">→</b>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="ai-message-list">
              {messages.map((message, index) => {
                const isAssistant = message.role === "assistant";
                const isLastAssistant =
                  isAssistant &&
                  index ===
                    messages.map((item) => item.role).lastIndexOf("assistant");

                return (
                  <article
                    key={`${message.role}-${index}-${message.content.slice(0, 16)}`}
                    className={`ai-message-row ${isAssistant ? "assistant" : "user"}`}
                  >
                    <div className="ai-message-avatar" aria-hidden="true">
                      {isAssistant ? "✦" : "M"}
                    </div>

                    <div className="ai-message-content">
                      <p className="ai-message-author">
                        {isAssistant ? "AskMyCity" : "You"}
                      </p>
                      <div className="ai-message-bubble">{message.content}</div>

                      {isLastAssistant && !loading && results.length > 0 && (
                        <div className="embedded-results">
                          <div className="embedded-results-header">
                            <div>
                              <strong>
                                {results.length} matching option
                                {results.length === 1 ? "" : "s"}
                              </strong>
                              {explanation && <p>{explanation}</p>}
                            </div>

                            <div className="embedded-results-controls">
                              {urgency && (
                                <span className={`chat-urgency urgency-${urgency}`}>
                                  {urgency}
                                </span>
                              )}

                              <div className="chat-view-toggle">
                                <button
                                  type="button"
                                  className={resultView === "list" ? "active" : ""}
                                  onClick={() => setResultView("list")}
                                >
                                  List
                                </button>
                                <button
                                  type="button"
                                  className={resultView === "map" ? "active" : ""}
                                  onClick={() => setResultView("map")}
                                >
                                  Map
                                </button>
                              </div>
                            </div>
                          </div>

                          {resultView === "list" ? (
                            <div className="chat-result-list">
                              {results.slice(0, 5).map((place, placeIndex) => (
                                <ResultCard
                                  key={place.id}
                                  place={place}
                                  rank={placeIndex + 1}
                                  onSelect={onPlaceSelect}
                                />
                              ))}

                              {results.length > 5 && (
                                <p className="more-results-note">
                                  Showing the top 5 of {results.length} matches.
                                  Refine your request to narrow the results.
                                </p>
                              )}
                            </div>
                          ) : (
                            <div className="chat-map-wrapper">
                              <BusinessMap
                                businesses={results}
                                onBusinessSelect={onPlaceSelect}
                              />
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </article>
                );
              })}

              {loading && (
                <article className="ai-message-row assistant">
                  <div className="ai-message-avatar" aria-hidden="true">✦</div>
                  <div className="ai-message-content">
                    <p className="ai-message-author">AskMyCity</p>
                    <div className="ai-message-bubble ai-typing-bubble">
                      <span />
                      <span />
                      <span />
                    </div>
                  </div>
                </article>
              )}

              {locationMessage && (
                <div className="ai-location-status">
                  <span aria-hidden="true">📍</span>
                  <p>{locationMessage}</p>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        <div className="ai-composer-area">
          <form className="ai-composer" onSubmit={handleSubmit}>
            <button type="button" className="composer-action" aria-label="More options">
              ＋
            </button>

            <textarea
              ref={textareaRef}
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                resizeTextarea();
              }}
              onKeyDown={handleKeyDown}
              placeholder="Ask about any local service..."
              rows={1}
              maxLength={1000}
              disabled={loading}
              aria-label="Message AskMyCity"
            />

            <button
              type="submit"
              className="ai-send-button"
              disabled={loading || query.trim().length < 3}
              aria-label="Send message"
            >
              {loading ? <span className="ai-send-spinner" /> : <span>↑</span>}
            </button>
          </form>

          <p className="ai-composer-note">
            AskMyCity can make mistakes. Confirm important business details.
          </p>
        </div>
      </div>
    </section>
  );
}
