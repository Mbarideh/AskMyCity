function Header() {
  return (
    <header>
      <h1>AskMyCity</h1>
      <p>Find trusted local services in your city</p>
    </header>
  );
}

export default Header;