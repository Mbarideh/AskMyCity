const API_BASE_URL = "http://127.0.0.1:8001";


async function handleResponse(response) {
  let data;

  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok) {
    throw new Error(
      data?.detail ||
      "The request could not be completed."
    );
  }

  return data;
}


function normalizeConversationMessages(
  messages = []
) {
  if (!Array.isArray(messages)) {
    return [];
  }

  return messages
    .filter((message) => {
      return (
        message &&
        (
          message.role === "user" ||
          message.role === "assistant"
        ) &&
        typeof message.content === "string" &&
        message.content.trim().length > 0
      );
    })
    .map((message) => {
      return {
        role: message.role,
        content: message.content
          .trim()
          .slice(0, 2000),
      };
    })
    .slice(-20);
}


export async function getPlaces({
  search = "",
  city = "",
  category = "",
  minimumRating = "",
} = {}) {
  const parameters = new URLSearchParams();

  if (search.trim()) {
    parameters.set(
      "search",
      search.trim()
    );
  }

  if (city.trim()) {
    parameters.set(
      "city",
      city.trim()
    );
  }

  if (category.trim()) {
    parameters.set(
      "category",
      category.trim()
    );
  }

  if (minimumRating !== "") {
    parameters.set(
      "minimum_rating",
      String(minimumRating)
    );
  }

  const url =
    parameters.toString().length > 0
      ? `${API_BASE_URL}/places?${parameters}`
      : `${API_BASE_URL}/places`;

  const response = await fetch(url);

  return handleResponse(response);
}


export async function getPlace(placeId) {
  const response = await fetch(
    `${API_BASE_URL}/places/${placeId}`
  );

  return handleResponse(response);
}


/**
 * Send a conversational AI search request.
 *
 * query:
 * The user's newest message.
 *
 * location:
 * Optional browser GPS coordinates.
 *
 * messages:
 * Previous user and assistant messages.
 */
export async function searchWithAI(
  query,
  location = null,
  messages = [],
) {
  const normalizedQuery = String(
    query || ""
  ).trim();

  if (normalizedQuery.length < 3) {
    throw new Error(
      "Please enter a longer search request."
    );
  }

  const normalizedMessages =
    normalizeConversationMessages(
      messages
    );

  const body = {
    query: normalizedQuery,
    messages: normalizedMessages,
  };

  if (
    location &&
    typeof location.latitude === "number" &&
    Number.isFinite(
      location.latitude
    ) &&
    typeof location.longitude === "number" &&
    Number.isFinite(
      location.longitude
    )
  ) {
    body.latitude =
      location.latitude;

    body.longitude =
      location.longitude;
  }

  console.log(
    "AI request being sent:",
    body
  );

  const response = await fetch(
    `${API_BASE_URL}/ai/search`,
    {
      method: "POST",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify(body),
    }
  );

  return handleResponse(response);
}


export async function registerUser(
  userData
) {
  const response = await fetch(
    `${API_BASE_URL}/auth/register`,
    {
      method: "POST",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify(
        userData
      ),
    }
  );

  return handleResponse(response);
}


export async function loginUser(
  credentials
) {
  const response = await fetch(
    `${API_BASE_URL}/auth/login`,
    {
      method: "POST",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify(
        credentials
      ),
    }
  );

  return handleResponse(response);
}